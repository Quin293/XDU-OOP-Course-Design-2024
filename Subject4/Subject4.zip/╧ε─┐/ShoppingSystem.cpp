#include "ShoppingSystem.h"
using namespace std;
// 构造函数，初始化管理员账户
ShoppingSystem::ShoppingSystem(std::string adminUname, std::string adminPwd) : admin(adminUname, adminPwd) {}
// 管理员登录函数
bool ShoppingSystem::adminLogin(std::string uname, std::string pwd) {
	return admin.login(uname, pwd);
}
// 顾客登录函数
bool ShoppingSystem::customerLogin(std::string uname, std::string pwd) {
	if (customers.find(uname) != customers.end()) {
		return customers[uname].login(uname, pwd);
	}
	return false;
}
// 顾客注册函数
void ShoppingSystem::registerCustomer(std::string uname, std::string pwd, std::string email, unordered_map<string, Product>& products) {
	if (customers.find(uname) == customers.end()) {
		customers[uname] = Customer(uname, pwd, email, products);
		std::cout << "注册成功！\n" << std::endl;
	} else {
		std::cout << "用户名已存在！\n" << std::endl;
	}
}
// 修改顾客密码函数
void ShoppingSystem::changeCustomerPassword(std::string uname, std::string newPwd, std::string email) {
	if (customers.find(uname) != customers.end() && customers.find(email) != customers.end()) {
		customers[uname].changePassword(newPwd);
		std::cout << "密码修改成功！\n" << std::endl;
	} else {
		std::cout << "用户不存在！\n" << std::endl;
	}
}

// 获取顾客对象函数
Customer& ShoppingSystem::getCustomer(string uname) {
	if (customers.find(uname) != customers.end()) {
		return customers[uname];
	} else {
		throw runtime_error("用户不存在！");
	}
}

	// 添加商品函数
void ShoppingSystem::addProduct(string name, double price, string description, int stock, double dis) {
	if (products.find(name) == products.end()) {
		products[name] = Product(name, price, description, stock, dis);
		cout << "商品添加成功！" << endl;
	} else {
		cout << "商品已存在！" << endl;
	}
}

// 删除商品函数
void ShoppingSystem::deleteProduct(string name) {
	if (products.find(name) != products.end()) {
		products.erase(name);
		cout << "商品删除成功！" << endl;
	} else {
		cout << "商品不存在！" << endl;
	}
}

// 修改商品信息函数
void ShoppingSystem::modifyProduct(string name, double price, string description, int stock, double dis) {
	if (products.find(name) != products.end()) {
		products[name] = Product(name, price, description, stock, dis);
		cout << "商品信息修改成功！" << endl;
	} else {
		cout << "商品不存在！" << endl;
	}
}

//修改商品库存函数
void ShoppingSystem::modifyStockProduct(string name, int modiStock, bool isAdd){
	if (products.find(name) != products.end()) {
		Product p = products[name];
		if(isAdd){
			p.stock+=modiStock;
		}else{
			p.stock-=modiStock;
		}
	} else {
		cout << "商品不存在！" << endl;
	}
};

// 查询商品信息函数
void ShoppingSystem::queryProduct(string name) {
	if (products.find(name) != products.end()) {
		Product p = products[name];
		cout << "商品名称: " << p.name << endl;
		cout << "商品单价: " << p.price << endl;
		cout << "商品描述: " << p.description << endl;
		cout << "商品库存: " << p.stock << endl;
		cout << "商品折扣: " << p.discount << endl;
	} else {
		cout << "商品不存在！" << endl;
	}
}

//返回商品价格函数
double ShoppingSystem::queryPrice(string name) {
	if (products.find(name) != products.end()) {
		Product p = products[name];
		return p.price;
	}else {
		cout << "商品不存在！" << endl;
	}
}

// 根据关键字推荐商品函数
void ShoppingSystem::recommendProduct(string keyword) {
	bool found = false;
	for (auto &p : products) {
		if (p.second.name.find(keyword) != string::npos) {
			cout << "推荐商品: " << p.second.name << endl;
			found = true;
		}
	}
	if (!found) {
		cout << "没有找到相关商品！" << endl;
	}
}

// 随机派送优惠券
void ShoppingSystem::distributeCoupon(string uname) {
	if (customers.find(uname) != customers.end()) {
		string couponCode = "COUPON" + to_string(rand() % 10000);
		double discount = (rand() % 50 + 1) / 100.0;  // 随机生成1%到50%的折扣
		coupons[couponCode] = discount;
		cout << "优惠券派送成功！优惠券码: " << couponCode << " 折扣: " << discount * 100 << "%" << endl;
	} else {
		cout << "用户不存在，无法派送优惠券！" << endl;
	}
}

// 结算时使用优惠券
double ShoppingSystem::applyCoupon(string couponCode, double total) {
	if (coupons.find(couponCode) != coupons.end()) {
		double discount = coupons[couponCode];
		total *= (1 - discount);
		coupons.erase(couponCode);  // 使用后删除优惠券
		cout << "优惠券使用成功！折扣: " << discount * 100 << "%" << endl;
	} else {
		cout << "优惠券无效！" << endl;
	}
	return total;
}

// 活动折扣
double ShoppingSystem::applyActivityDiscount(double total) {
	double discount = 0.1;  
	total *= (1 - discount);
	cout << "活动折扣: " << discount * 100 << "%" << endl;
	return total;
}

unordered_map<string, Product>& ShoppingSystem::getProducts(){
	return products;
}

