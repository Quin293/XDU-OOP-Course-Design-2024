#ifndef SHOPPINGCART_H
#define SHOPPINGCART_H


#include <iostream>
#include <unordered_map>
#include <string>
#include "Product.h"
//#include "ShoppingSystem.h"
using namespace std;

class ShoppingCart {
private:
	std::unordered_map<std::string, int> cart;  // 购物车，存储商品名称和购买数量
	unordered_map<string, Product> products;  // 引用商品信息哈希表
	double total;
public:
	ShoppingCart();
	ShoppingCart(unordered_map<string, Product> prod);
	void addProduct(std::string name, int quantity);
	void viewCart();
	void removeProduct(std::string name);
	void modifyProductQuantity(std::string name, int quantity);
	void totalPrice();
	double calculateTotalPrice();
	void checkout();
	void setProducts(unordered_map<string, Product> product);
};

#endif
