#include "ShoppingCart.h"
using namespace std;
ShoppingCart::ShoppingCart(){
	
}
ShoppingCart::ShoppingCart(unordered_map<string, Product> prod) : products(prod), total(0.0) {}

void ShoppingCart::addProduct(std::string name, int quantity) {
	if(products.find(name) == products.end()){
		cout << "商品不存在！" << endl;
		return;
	}
	if (cart.find(name) != cart.end()) {
		cart[name] += quantity;
	} else {
		cart[name] = quantity;
	}
	std::cout << "商品添加到购物车成功！" << std::endl;
}

void ShoppingCart::viewCart() {
	if (cart.empty()) {
		std::cout << "购物车为空！" << std::endl;
	} else {
		for (auto &item : cart) {
			std::cout << "商品名称: " << item.first << " 数量: " << item.second << " 原价：" << products[item.first].price << " 折扣：" << products[item.first].discount << endl;
		}
	}
}

void ShoppingCart::removeProduct(std::string name) {
	if (cart.find(name) != cart.end()) {
		cart.erase(name);
		std::cout << "商品从购物车中删除成功！" << std::endl;
	} else {
		std::cout << "购物车中没有该商品！" << std::endl;
	}
}

void ShoppingCart::modifyProductQuantity(std::string name, int quantity) {
	if (cart.find(name) != cart.end()) {
		cart[name] = quantity;
		std::cout << "商品数量修改成功！" << std::endl;
	} else {
		std::cout << "购物车中没有该商品！" << std::endl;
	}
}

// 计算购物车中所有商品的总价
double ShoppingCart::calculateTotalPrice() {
	total = 0.0;
	for (auto &item : cart) {
		total += products[item.first].price * item.second * (1 - products[item.first].discount);
	}
	return total;
}

// 结算购物车中的商品
void ShoppingCart::checkout() {
	//double total = calculateTotalPrice();
	cart.clear();  // 清空购物车
}

void ShoppingCart::setProducts(unordered_map<string, Product> product) {
	products = product;
}
