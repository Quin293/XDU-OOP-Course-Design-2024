#ifndef SHOPPINGCART_H
#define SHOPPINGCART_H


#include <iostream>
#include <unordered_map>
#include <string>
#include <fstream>
#include <vector>
#include <ctime>
#include "Product.h"
//#include "ShoppingSystem.h"
using namespace std;

class ShoppingCart {
private:
	std::unordered_map<std::string, int> cart;  // 购物车，存储商品名称和购买数量
	unordered_map<string, Product> products;  // 引用商品信息哈希表
	double total;
	
	struct PurchaseRecord {
		string productName;
		int quantity;
		double price;
		time_t purchaseTime;
	};
	
	vector<PurchaseRecord> purchaseHistory;  // 购物历史记录
public:
	ShoppingCart();
	ShoppingCart(unordered_map<string, Product> prod);
	void addProduct(std::string name, int quantity);
	void viewCart();
	void removeProduct(std::string name);
	void modifyProductQuantity(std::string name, int quantity);
	void totalPrice();
	double calculateTotalPrice();
	void checkout();
	unordered_map<string, Product>& getProducts();
	void setProducts(unordered_map<string, Product> product);
	void saveCart(const string& filename);  // 保存购物车到文件
	void loadCart(const string& filename);  // 从文件加载购物车
	void savePurchaseHistory(const string& filename);  // 保存购物历史到文件
	void loadPurchaseHistory(const string& filename);  // 从文件加载购物历史
	void viewPurchaseHistory();  // 查看购物历史
	void analyzePurchaseHistory(time_t startTime, time_t endTime);  // 分析购物历史
};

#endif
