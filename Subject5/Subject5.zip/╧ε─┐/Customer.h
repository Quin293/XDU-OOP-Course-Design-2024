#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "User.h"
#include "ShoppingCart.h"
#include "Product.h"
#include <string>
using namespace std;
class Customer : public User {
private:
	std::string email;  // 电子邮箱
	ShoppingCart cart;  //购物车
public:
	Customer();//默认构造函数
	Customer(std::string uname, std::string pwd, std::string mail, unordered_map<string, Product>& products );// 构造函数，初始化用户名、密码和电子邮箱
	bool login(std::string uname, std::string pwd) override;// 实现登录验证函数
	void changePassword(std::string newPwd);// 修改密码
	std::string getEmail();// 获取电子邮箱
	ShoppingCart& getCart();//获取购物车
	void saveCart(const string& filename);  // 保存购物车到文件
	void loadCart(const string& filename);  // 从文件加载购物车
	void savePurchaseHistory(const string& filename);  // 保存购物历史到文件
	void loadPurchaseHistory(const string& filename);  // 从文件加载购物历史
	void viewPurchaseHistory();  // 查看购物历史
	void analyzePurchaseHistory(time_t startTime, time_t endTime);  // 分析购物历史
};

#endif
