#include "Customer.h"
//默认构造函数
Customer::Customer() : User("", ""), email(""), cart() {}
// 构造函数，初始化用户名、密码和电子邮箱
Customer::Customer(std::string uname, std::string pwd, std::string mail, unordered_map<string, Product>& products) 
: User(uname, pwd), email(mail), cart(products){}
// 实现登录验证函数
bool Customer::login(std::string uname, std::string pwd) {
	return (username == uname && password == pwd);
}
// 修改密码
void Customer::changePassword(std::string newPwd) {
	password = newPwd;
}
// 获取电子邮箱
std::string Customer::getEmail() {
	return email;
}
//获取购物车
ShoppingCart& Customer::getCart() {
	return cart;
}
// 保存购物车到文件
void Customer::saveCart(const string& filename) {
	cart.saveCart(filename);
}

// 从文件加载购物车
void Customer::loadCart(const string& filename) {
	cart.loadCart(filename);
}

// 保存购物历史到文件
void Customer::savePurchaseHistory(const string& filename) {
	cart.savePurchaseHistory(filename);
}

// 从文件加载购物历史
void Customer::loadPurchaseHistory(const string& filename) {
	cart.loadPurchaseHistory(filename);
}

// 查看购物历史
void Customer::viewPurchaseHistory() {
	cart.viewPurchaseHistory();
}

// 分析购物历史
void Customer::analyzePurchaseHistory(time_t startTime, time_t endTime) {
	cart.analyzePurchaseHistory(startTime, endTime);
}

