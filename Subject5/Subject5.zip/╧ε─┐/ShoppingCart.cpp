#include "ShoppingCart.h"
using namespace std;
ShoppingCart::ShoppingCart(){
	
}
ShoppingCart::ShoppingCart(unordered_map<string, Product> prod) : products(prod), total(0.0) {}

void ShoppingCart::addProduct(std::string name, int quantity) {
	if(products.find(name) == products.end()){
		cout << "商品不存在！" << endl;
		return;
	}
	if (cart.find(name) != cart.end()) {
		cart[name] += quantity;
		products[name].stock -= quantity;
	} else {
		cart[name] = quantity;
		products[name].stock -= quantity;
	}
	std::cout << "商品添加到购物车成功！" << std::endl;
}

void ShoppingCart::viewCart() {
	if (cart.empty()) {
		std::cout << "购物车为空！" << std::endl;
	} else {
		for (auto &item : cart) {
			std::cout << "商品名称: " << item.first << " 数量: " << item.second << " 原价：" << products[item.first].price << " 折扣：" << products[item.first].discount << endl;
		}
	}
}

void ShoppingCart::removeProduct(std::string name) {
	if (cart.find(name) != cart.end()) {
		cart.erase(name);
		std::cout << "商品从购物车中删除成功！" << std::endl;
	} else {
		std::cout << "购物车中没有该商品！" << std::endl;
	}
}

void ShoppingCart::modifyProductQuantity(std::string name, int quantity) {
	if (cart.find(name) != cart.end()) {
		cart[name] = quantity;
		std::cout << "商品数量修改成功！" << std::endl;
	} else {
		std::cout << "购物车中没有该商品！" << std::endl;
	}
}

// 计算购物车中所有商品的总价
double ShoppingCart::calculateTotalPrice() {
	total = 0.0;
	for (auto &item : cart) {
		total += products[item.first].price * item.second * (1 - products[item.first].discount);
	}
	return total;
}

// 结算购物车中的商品
void ShoppingCart::checkout() {
	
	time_t now = time(0);  // 获取当前时间
	
	// 保存购物记录
	for (auto &item : cart) {
		PurchaseRecord record = {item.first, item.second, products[item.first].price, now};
		purchaseHistory.push_back(record);
	}
	cart.clear();  // 清空购物车
}

unordered_map<string, Product>& ShoppingCart::getProducts() {
	return products;
}

void ShoppingCart::setProducts(unordered_map<string, Product> product) {
	products = product;
}

// 保存购物车到文件
void ShoppingCart::saveCart(const string& filename) {
	ofstream file(filename);
	if (file.is_open()) {
		for (auto &item : cart) {
			file << item.first << " " << item.second << endl;
		}
		file.close();
		cout << "购物车保存成功！" << endl;
	} else {
		cout << "无法打开文件保存购物车！" << endl;
	}
}

// 从文件加载购物车
void ShoppingCart::loadCart(const string& filename) {
	ifstream file(filename);
	if (file.is_open()) {
		cart.clear();  // 清空当前购物车
		string name;
		int quantity;
		while (file >> name >> quantity) {
			cart[name] = quantity;
		}
		file.close();
		cout << "购物车加载成功！" << endl;
	} else {
		cout << "无法打开文件加载购物车！" << endl;
	}
}

// 保存购物历史到文件
void ShoppingCart::savePurchaseHistory(const string& filename) {
	ofstream file(filename);
	if (file.is_open()) {
		for (auto &record : purchaseHistory) {
			file << record.productName << " " << record.quantity << " " << record.price << " " << record.purchaseTime << endl;
		}
		file.close();
		cout << "购物历史保存成功！" << endl;
	} else {
		cout << "无法打开文件保存购物历史！" << endl;
	}
}

// 从文件加载购物历史
void ShoppingCart::loadPurchaseHistory(const string& filename) {
	ifstream file(filename);
	if (file.is_open()) {
		purchaseHistory.clear();  // 清空当前购物历史
		string name;
		int quantity;
		double price;
		time_t purchaseTime;
		while (file >> name >> quantity >> price >> purchaseTime) {
			PurchaseRecord record = {name, quantity, price, purchaseTime};
			purchaseHistory.push_back(record);
		}
		file.close();
		cout << "购物历史加载成功！" << endl;
	} else {
		cout << "无法打开文件加载购物历史！" << endl;
	}
}

// 查看购物历史
void ShoppingCart::viewPurchaseHistory() {
	if (purchaseHistory.empty()) {
		cout << "购物历史为空！" << endl;
	} else {
		for (auto &record : purchaseHistory) {
			cout << "商品名称: " << record.productName << " 数量: " << record.quantity << " 单价: " << record.price << " 购买时间: " << ctime(&record.purchaseTime);
		}
	}
}

// 分析购物历史
void ShoppingCart::analyzePurchaseHistory(time_t startTime, time_t endTime) {
	unordered_map<string, double> analysis;
	for (auto &record : purchaseHistory) {
		if (record.purchaseTime >= startTime && record.purchaseTime <= endTime) {
			analysis[record.productName] += record.price * record.quantity;
		}
	}
	
	if (analysis.empty()) {
		cout << "在指定时间段内没有购买记录！" << endl;
	} else {
		for (auto &item : analysis) {
			cout << "商品名称: " << item.first << " 总金额: " << item.second << endl;
		}
	}
}

